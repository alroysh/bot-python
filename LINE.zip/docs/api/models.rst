Models
======

Introduction
------------

This page intorduce you a list of core models which is used in LINE API.
The name of each models tell you what it is intuitively.
In most cases, you don't have to create this instances, but if you want to change
*line*, I hope this documents wil help you to find what you want.


LineMessage
-----------

.. autoclass:: line.LineMessage
    :members:

LineBase
--------

.. autoclass:: line.LineBase
    :members:

LineContct
----------

.. autoclass:: line.LineContact
    :members:

LineRoom
---------

.. autoclass:: line.LineRoom
    :members:

LineGroup
---------

.. autoclass:: line.LineGroup
    :members:
