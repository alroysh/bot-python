from line import LineClient

try:
   client = LineClient("codexcodex12@gmail.com", "codexcodex123")
   client = LineClient("codexcodex12", "codexcodex123")
   client = LineClient(authToken=authToken)
   print client.authToken
except:
   print "Login Failed"

while True:
   op_list = []

   for op in client.longPoll():
      op_list.append(op)

   for op in op_list:
      sender   = op[0]
      receiver = op[1]
      message  = op[2]

      msg = message.text
      #receiver.sendMessage("[%s] %s" % (sender.name, msg)) #this send message to ourselft that make infinity loop
      sender.sendMessage("[%s] %s" % (sender.name, msg)) #send message back to sender
	  
while True:
    try:
        for op in clinet.longPoll():
            pass # your code
    except:
        continue